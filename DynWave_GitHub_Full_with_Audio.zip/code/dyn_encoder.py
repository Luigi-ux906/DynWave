# Dyn Encoder: converts audio into mantissa and gain streams
def encode(audio_block):
    gain = max(abs(audio_block))
    mantissa = (audio_block / gain) * 127  # quantize to 8-bit range
    return mantissa.astype(int), int(gain * 63)
