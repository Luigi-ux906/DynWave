# DynWave Dual-Branch Autoencoder (simplified)
import torch.nn as nn

class DynWaveAutoencoder(nn.Module):
    def __init__(self):
        super().__init__()
        self.encoder = nn.Sequential(nn.Conv1d(1, 16, 3), nn.ReLU())
        self.decoder = nn.Sequential(nn.ConvTranspose1d(16, 1, 3))

    def forward(self, mantissa, gain):
        z = self.encoder(mantissa)
        out = self.decoder(z)
        return out * gain
