# DynWave: Dynamic Gain-Aware Audio Representation

This repository contains the full code and supplementary material for the ML project *DynWave*.

## 📁 Contents
- `code/`: Scripts for audio encoding and model training
- `audio/`: Example audio files (original + reconstructed)
- `notebooks/`: Demo notebook showing how DynWave works
- `results/`: Output metrics and evaluation placeholders
- `main.tex`: Report source (already submitted)

## 🚀 Running the Code

```bash
pip install -r requirements.txt
python code/train.py
```

Or launch the demo:

```bash
jupyter notebook notebooks/Demo.ipynb
```
